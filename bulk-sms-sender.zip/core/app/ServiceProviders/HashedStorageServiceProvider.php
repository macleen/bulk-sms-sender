<?php namespace App\ServiceProviders;

use App\Support\HashedStorage;

class HashedStorageServiceProvider extends ServiceProvider {

    public function boot(): void {
    }
}