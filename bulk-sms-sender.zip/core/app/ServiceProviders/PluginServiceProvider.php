<?php namespace App\ServiceProviders;

use App\ServiceProviders\ServiceProvider;


class PluginServiceProvider extends ServiceProvider {

    public function register(): void {
      

    }    
    
    public function boot(): void {
      

    }


}