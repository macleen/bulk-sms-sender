<select id="delay-box" name="delay" title="delay interval">
    <option value="1">01 sec</option>
    <option value="2">02 sec</option>
    <option value="3">03 sec</option>
    <option value="4">04 sec</option>
    <option value="5">05 sec</option>
    <option value="6">06 sec</option>
    <option value="7">07 sec</option>
    <option value="8">08 sec</option>
    <option value="9">09 sec</option>
    <option value="10" selected>10 sec</option>
    <option value="11">11 sec</option>
    <option value="12">12 sec</option>
    <option value="13">13 sec</option>
    <option value="14">14 sec</option>
    <option value="15">15 sec</option>
    <option value="16">16 sec</option>
    <option value="17">17 sec</option>
    <option value="18">18 sec</option>
    <option value="19">19 sec</option>
    <option value="20">20 sec</option>
    <option value="25">25 sec</option>
    <option value="30">30 sec</option>
    <option value="40">40 sec</option>
    <option value="50">50 sec</option>
</select>