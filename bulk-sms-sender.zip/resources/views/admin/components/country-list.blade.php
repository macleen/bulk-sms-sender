<select id="full_country_name" class="country-select-box" style="font-size:1.2rem;padding-left: 8px;">
    <option value="" data-dial_code_length="">Country</option>
    <option value="AF" data-dial_code_length="2">Afghanistan</option>
    <option value="AL" data-dial_code_length="3">Albania</option>
    <option value="DZ" data-dial_code_length="3">Algeria</option>
    <option value="AS" data-dial_code_length="3">American Samoa</option>
    <option value="AD" data-dial_code_length="3">Andorra</option>
    <option value="AO" data-dial_code_length="3">Angola</option>
    <option value="AI" data-dial_code_length="4">Anguilla</option>
    <option value="AQ" data-dial_code_length="3">Antarctica</option>
    <option value="AG" data-dial_code_length="4">Antigua and Barbuda</option>
    <option value="AR" data-dial_code_length="2">Argentina</option>
    <option value="AM" data-dial_code_length="3">Armenia</option>
    <option value="AW" data-dial_code_length="3">Aruba</option>
    <option value="AU" data-dial_code_length="2">Australia</option>
    <option value="AT" data-dial_code_length="2">Austria</option>
    <option value="AZ" data-dial_code_length="3">Azerbaijan</option>
    <option value="BS" data-dial_code_length="4">Bahamas</option>
    <option value="BH" data-dial_code_length="3">Bahrain</option>
    <option value="BD" data-dial_code_length="3">Bangladesh</option>
    <option value="BB" data-dial_code_length="4">Barbados</option>
    <option value="BY" data-dial_code_length="3">Belarus</option>
    <option value="BE" data-dial_code_length="2">Belgium</option>
    <option value="BZ" data-dial_code_length="3">Belize</option>
    <option value="BJ" data-dial_code_length="3">Benin</option>
    <option value="BM" data-dial_code_length="4">Bermuda</option>
    <option value="BT" data-dial_code_length="3">Bhutan</option>
    <option value="BO" data-dial_code_length="3">Bolivia</option>
    <option value="BA" data-dial_code_length="3">Bosnia and Herzegowina</option>
    <option value="BW" data-dial_code_length="3">Botswana</option>
    <option value="BR" data-dial_code_length="2">Brazil</option>
    <option value="BN" data-dial_code_length="3">Brunei Darussalam</option>
    <option value="BG" data-dial_code_length="3">Bulgaria</option>
    <option value="BF" data-dial_code_length="3">Burkina Faso</option>
    <option value="BI" data-dial_code_length="3">Burundi</option>
    <option value="KH" data-dial_code_length="3">Cambodia</option>
    <option value="CM" data-dial_code_length="3">Cameroon</option>
    <option value="CA" data-dial_code_length="1">Canada</option>
    <option value="CV" data-dial_code_length="3">Cape Verde</option>
    <option value="KY" data-dial_code_length="4">Cayman Islands</option>
    <option value="CF" data-dial_code_length="3">Central African Republic</option>
    <option value="TD" data-dial_code_length="3">Chad</option>
    <option value="CL" data-dial_code_length="2">Chile</option>
    <option value="CN" data-dial_code_length="2">China</option>
    <option value="CX" data-dial_code_length="2">Christmas Island</option>
    <option value="CO" data-dial_code_length="2">Colombia</option>
    <option value="KM" data-dial_code_length="3">Comoros</option>
    <option value="CG" data-dial_code_length="3">Congo</option>
    <option value="CD" data-dial_code_length="3">Congo, the Democratic Republic of the</option>
    <option value="CK" data-dial_code_length="3">Cook Islands</option>
    <option value="CR" data-dial_code_length="3">Costa Rica</option>
    <option value="CI" data-dial_code_length="3">Cote d'Ivoire</option>
    <option value="HR" data-dial_code_length="3">Croatia (Hrvatska)</option>
    <option value="CU" data-dial_code_length="2">Cuba</option>
    <option value="CY" data-dial_code_length="3">Cyprus</option>
    <option value="CZ" data-dial_code_length="3">Czech Republic</option>
    <option value="DK" data-dial_code_length="2">Denmark</option>
    <option value="DJ" data-dial_code_length="3">Djibouti</option>
    <option value="DM" data-dial_code_length="4">Dominica</option>
    <option value="DO" data-dial_code_length="4">Dominican Republic</option>
    <option value="TP" data-dial_code_length="3">East Timor</option>
    <option value="EC" data-dial_code_length="3">Ecuador</option>
    <option value="EG" data-dial_code_length="2">Egypt</option>
    <option value="SV" data-dial_code_length="3">El Salvador</option>
    <option value="GQ" data-dial_code_length="3">Equatorial Guinea</option>
    <option value="ER" data-dial_code_length="3">Eritrea</option>
    <option value="EE" data-dial_code_length="3">Estonia</option>
    <option value="ET" data-dial_code_length="3">Ethiopia</option>
    <option value="FK" data-dial_code_length="3">Falkland Islands (Malvinas)</option>
    <option value="FO" data-dial_code_length="3">Faroe Islands</option>
    <option value="FJ" data-dial_code_length="3">Fiji</option>
    <option value="FI" data-dial_code_length="3">Finland</option>
    <option value="FR" data-dial_code_length="2">France</option>
    <option value="GF" data-dial_code_length="3">French Guiana</option>
    <option value="PF" data-dial_code_length="3">French Polynesia</option>
    <option value="TF" data-dial_code_length="3">French Southern Territories</option>
    <option value="GA" data-dial_code_length="3">Gabon</option>
    <option value="GM" data-dial_code_length="3">Gambia</option>
    <option value="GE" data-dial_code_length="3">Georgia</option>
    <option value="DE" data-dial_code_length="2">Germany</option>
    <option value="GH" data-dial_code_length="3">Ghana</option>
    <option value="GI" data-dial_code_length="3">Gibraltar</option>
    <option value="GR" data-dial_code_length="2">Greece</option>
    <option value="GL" data-dial_code_length="3">Greenland</option>
    <option value="GD" data-dial_code_length="4">Grenada</option>
    <option value="GP" data-dial_code_length="3">Guadeloupe</option>
    <option value="GU" data-dial_code_length="4">Guam</option>
    <option value="GT" data-dial_code_length="3">Guatemala</option>
    <option value="GN" data-dial_code_length="3">Guinea</option>
    <option value="GW" data-dial_code_length="3">Guinea-Bissau</option>
    <option value="GY" data-dial_code_length="3">Guyana</option>
    <option value="HT" data-dial_code_length="3">Haiti</option>
    <option value="HN" data-dial_code_length="3">Honduras</option>
    <option value="HK" data-dial_code_length="3">Hong Kong</option>
    <option value="HU" data-dial_code_length="2">Hungary</option>
    <option value="IS" data-dial_code_length="3">Iceland</option>
    <option value="IN" data-dial_code_length="2">India</option>
    <option value="ID" data-dial_code_length="2">Indonesia</option>
    <option value="IR" data-dial_code_length="2">Iran (Islamic Republic of)</option>
    <option value="IQ" data-dial_code_length="3">Iraq</option>
    <option value="IE" data-dial_code_length="3">Ireland</option>
    <option value="IL" data-dial_code_length="3">Israel</option>
    <option value="IT" data-dial_code_length="2">Italy</option>
    <option value="JM" data-dial_code_length="4">Jamaica</option>
    <option value="JP" data-dial_code_length="2">Japan</option>
    <option value="JO" data-dial_code_length="3">Jordan</option>
    <option value="KZ" data-dial_code_length="1">Kazakhstan</option>
    <option value="KE" data-dial_code_length="3">Kenya</option>
    <option value="KI" data-dial_code_length="3">Kiribati</option>
    <option value="KP" data-dial_code_length="3">Korea, Democratic People's Republic of</option>
    <option value="KR" data-dial_code_length="2">Korea, Republic of</option>
    <option value="KW" data-dial_code_length="3">Kuwait</option>
    <option value="KG" data-dial_code_length="3">Kyrgyzstan</option>
    <option value="LA" data-dial_code_length="3">Lao People's Democratic Republic</option>
    <option value="LV" data-dial_code_length="3">Latvia</option>
    <option value="LB" data-dial_code_length="3">Lebanon</option>
    <option value="LS" data-dial_code_length="3">Lesotho</option>
    <option value="LR" data-dial_code_length="3">Liberia</option>
    <option value="LY" data-dial_code_length="3">Libyan Arab Jamahiriya</option>
    <option value="LI" data-dial_code_length="3">Liechtenstein</option>
    <option value="LT" data-dial_code_length="3">Lithuania</option>
    <option value="LU" data-dial_code_length="3">Luxembourg</option>
    <option value="MO" data-dial_code_length="3">Macau</option>
    <option value="MK" data-dial_code_length="3">Macedonia, The Former Yugoslav Republic of</option>
    <option value="MG" data-dial_code_length="3">Madagascar</option>
    <option value="MW" data-dial_code_length="3">Malawi</option>
    <option value="MY" data-dial_code_length="2">Malaysia</option>
    <option value="MV" data-dial_code_length="3">Maldives</option>
    <option value="ML" data-dial_code_length="3">Mali</option>
    <option value="MT" data-dial_code_length="3">Malta</option>
    <option value="MH" data-dial_code_length="3">Marshall Islands</option>
    <option value="MQ" data-dial_code_length="3">Martinique</option>
    <option value="MR" data-dial_code_length="3">Mauritania</option>
    <option value="MU" data-dial_code_length="3">Mauritius</option>
    <option value="YT" data-dial_code_length="3">Mayotte</option>
    <option value="MX" data-dial_code_length="2">Mexico</option>
    <option value="FM" data-dial_code_length="3">Micronesia, Federated States of</option>
    <option value="MD" data-dial_code_length="3">Moldova, Republic of</option>
    <option value="MC" data-dial_code_length="3">Monaco</option>
    <option value="MN" data-dial_code_length="3">Mongolia</option>
    <option value="MS" data-dial_code_length="4">Montserrat</option>
    <option value="MA" data-dial_code_length="3">Morocco</option>
    <option value="MZ" data-dial_code_length="3">Mozambique</option>
    <option value="MM" data-dial_code_length="2">Myanmar</option>
    <option value="NA" data-dial_code_length="3">Namibia</option>
    <option value="NR" data-dial_code_length="3">Nauru</option>
    <option value="NP" data-dial_code_length="3">Nepal</option>
    <option value="NL" data-dial_code_length="2">Netherlands</option>
    <option value="AN" data-dial_code_length="3">Netherlands Antilles</option>
    <option value="NC" data-dial_code_length="3">New Caledonia</option>
    <option value="NZ" data-dial_code_length="2">New Zealand</option>
    <option value="NI" data-dial_code_length="3">Nicaragua</option>
    <option value="NE" data-dial_code_length="3">Niger</option>
    <option value="NG" data-dial_code_length="3">Nigeria</option>
    <option value="NU" data-dial_code_length="3">Niue</option>
    <option value="NF" data-dial_code_length="3">Norfolk Island</option>
    <option value="MP" data-dial_code_length="4">Northern Mariana Islands</option>
    <option value="NO" data-dial_code_length="2">Norway</option>
    <option value="OM" data-dial_code_length="3">Oman</option>
    <option value="PK" data-dial_code_length="2">Pakistan</option>
    <option value="PW" data-dial_code_length="3">Palau</option>
    <option value="PA" data-dial_code_length="3">Panama</option>
    <option value="PG" data-dial_code_length="3">Papua New Guinea</option>
    <option value="PY" data-dial_code_length="3">Paraguay</option>
    <option value="PE" data-dial_code_length="2">Peru</option>
    <option value="PH" data-dial_code_length="2">Philippines</option>
    <option value="PL" data-dial_code_length="2">Poland</option>
    <option value="PT" data-dial_code_length="3">Portugal</option>
    <option value="PR" data-dial_code_length="4">Puerto Rico</option>
    <option value="QA" data-dial_code_length="3">Qatar</option>
    <option value="RE" data-dial_code_length="3">Reunion</option>
    <option value="RO" data-dial_code_length="2">Romania</option>
    <option value="RU" data-dial_code_length="1">Russian Federation</option>
    <option value="RW" data-dial_code_length="3">Rwanda</option>
    <option value="KN" data-dial_code_length="4">Saint Kitts and Nevis</option> 
    <option value="LC" data-dial_code_length="4">Saint LUCIA</option>
    <option value="VC" data-dial_code_length="4">Saint Vincent and the Grenadines</option>
    <option value="SM" data-dial_code_length="3">San Marino</option>
    <option value="ST" data-dial_code_length="3">Sao Tome and Principe</option> 
    <option value="SA" data-dial_code_length="3">Saudi Arabia</option>
    <option value="SN" data-dial_code_length="3">Senegal</option>
    <option value="SC" data-dial_code_length="3">Seychelles</option>
    <option value="SL" data-dial_code_length="3">Sierra Leone</option>
    <option value="SG" data-dial_code_length="2">Singapore</option>
    <option value="SK" data-dial_code_length="3">Slovakia (Slovak Republic)</option>
    <option value="SI" data-dial_code_length="3">Slovenia</option>
    <option value="SB" data-dial_code_length="3">Solomon Islands</option>
    <option value="SO" data-dial_code_length="3">Somalia</option>
    <option value="ZA" data-dial_code_length="2">South Africa</option>
    <option value="ES" data-dial_code_length="2">Spain</option>
    <option value="LK" data-dial_code_length="2">Sri Lanka</option>
    <option value="SD" data-dial_code_length="3">Sudan</option>
    <option value="SR" data-dial_code_length="3">Suriname</option>
    <option value="SZ" data-dial_code_length="3">Swaziland</option>
    <option value="SE" data-dial_code_length="2">Sweden</option>
    <option value="CH" data-dial_code_length="2">Switzerland</option>
    <option value="SY" data-dial_code_length="3">Syrian Arab Republic</option>
    <option value="TW" data-dial_code_length="3">Taiwan, Province of China</option>
    <option value="TJ" data-dial_code_length="3">Tajikistan</option>
    <option value="TZ" data-dial_code_length="3">Tanzania, United Republic of</option>
    <option value="TH" data-dial_code_length="2">Thailand</option>
    <option value="TG" data-dial_code_length="3">Togo</option>
    <option value="TK" data-dial_code_length="3">Tokelau</option>
    <option value="TO" data-dial_code_length="3">Tonga</option>
    <option value="TT" data-dial_code_length="4">Trinidad and Tobago</option>
    <option value="TN" data-dial_code_length="3">Tunisia</option>
    <option value="TR" data-dial_code_length="2">Turkey</option>
    <option value="TM" data-dial_code_length="3">Turkmenistan</option>
    <option value="TC" data-dial_code_length="4">Turks and Caicos Islands</option>
    <option value="TV" data-dial_code_length="3">Tuvalu</option>
    <option value="UG" data-dial_code_length="3">Uganda</option>
    <option value="UA" data-dial_code_length="3">Ukraine</option>
    <option value="AE" data-dial_code_length="3">United Arab Emirates</option>
    <option value="GB" data-dial_code_length="2">United Kingdom</option>
    <option value="US" data-dial_code_length="1">United States</option>
    <option value="UM" data-dial_code_length="4">United States Minor Outlying Islands</option>
    <option value="UY" data-dial_code_length="3">Uruguay</option>
    <option value="UZ" data-dial_code_length="3">Uzbekistan</option>
    <option value="VU" data-dial_code_length="3">Vanuatu</option>
    <option value="VE" data-dial_code_length="2">Venezuela</option>
    <option value="VN" data-dial_code_length="2">Viet Nam</option>
    <option value="VI" data-dial_code_length="4">Virgin Islands (U.S.)</option>
    <option value="YE" data-dial_code_length="3">Yemen</option>
    <option value="YU" data-dial_code_length="2">Yugoslavia</option>
    <option value="ZM" data-dial_code_length="3">Zambia</option>
    <option value="ZW" data-dial_code_length="3">Zimbabwe</option>
</select>