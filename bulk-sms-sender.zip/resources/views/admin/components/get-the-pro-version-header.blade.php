<div style="margin-left:6%;margin-bottom: 1vh;width:90%; display:flex; justify-content:center;font-family: sans-serif;">
    <div style="text-align: center;padding: 8px 20px;border: gray thin solid;background-color: #451111;border-radius: 5px;color: #e7f2f2ba;">
        Get the <a href="#"><span class="{{__COMMERCIAL_TYPE_PRO__}}-licence">Pro</span></a> Version
    </div>
</div>
