<select id="name_format" name="name_format" class="custom-select"
        title="what part of the name you want to include in the SMS message">
    <option value="FirstName">First Name</option>
    <option value="SecondName">Second Name</option>
    <option value="LastName">Last Name</option>
    <option value="skip1st">Skip First Part</option>
    <option value="FullName" selected>Full Name</option>
</select>
