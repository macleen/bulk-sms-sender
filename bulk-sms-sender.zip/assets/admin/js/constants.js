//-----------------------------------
const yes_no          = ['No','Yes'];
const plugin_name     = 'SMS-BULK-SENDER';
const license         = usageParameters.licence;
const field_seperator = ';';
const settings_prefix =  'provider_settings__';
const default_line_format = 'P-N';
const default_delay = +jQuery("#delay-box").children("option:selected").val();

