<?php

return [
    'views' =>  resources_path('views'),
    'cache' =>  storage_path('cache'),
];