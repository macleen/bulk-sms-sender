<?php namespace ThisPlugin\Http\Controllers;

use ThisPlugin\Http\Controllers\BaseController;

class ProviderController extends BaseController { }