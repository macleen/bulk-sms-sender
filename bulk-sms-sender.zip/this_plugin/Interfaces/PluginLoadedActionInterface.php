<?php namespace ThisPlugin\Interfaces;
#-------------------------------------------------------------------------------------------  
#
#-------------------------------------------------------------------------------------------  

interface PluginLoadedActionInterface {
    public function exported_callbacks( ): void;
   
}